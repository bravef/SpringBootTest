package com.selftest.xdclass.xdvideo.provider;

import com.selftest.xdclass.xdvideo.domain.Video;
import org.apache.ibatis.jdbc.SQL;

/**
 * video构件动态sql语句
 */
public class VideoProvider {
    /**
     * 更新video动态语句
     * @param video
     * @return
     */
    public String updateVideo(final Video video){
        return new SQL(){{
            UPDATE("video");

            //条件写法.
            if(video.getTitle()!= null){
                SET("title=#{title}");
            }
            if(video.getSummary()!= null){
                SET("summary=#{summary}");
            }
            if(video.getCoverImg()!= null){
                SET("cover_img=#{cover_img}");
            }
            if(video.getViewNum()!= null){
                SET("view_num=#{view_num}");
            }
            if(video.getPrice()!= null){
                SET("price=#{price}");
            }
            if(video.getCreateTime()!= null){
                SET("create_time=#{create_time}");
            }
            if(video.getOnline()!= null){
                SET("online=#{online}");
            }
            if(video.getPoint()!= null){
                SET("point=#{point}");
            }


            WHERE("id=#{id}");
        }}.toString();

    }
}
